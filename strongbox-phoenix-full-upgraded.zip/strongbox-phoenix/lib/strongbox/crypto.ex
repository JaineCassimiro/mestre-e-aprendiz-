defmodule Strongbox.Crypto do
  @moduledoc """
  Módulo para hash de senhas e verificação segura.
  """

  alias Argon2

  @salt "random_salt_lumin"

  def hash_password(password) do
    Argon2.add_hash(password, salt: @salt)
  end

  def verify_password(password, hash) do
    Argon2.verify_pass(password, hash)
  end
end

defmodule Strongbox.Cache do
  use GenServer

  def start_link(_) do
    GenServer.start_link(__MODULE__, nil, name: __MODULE__)
  end

  def init(_) do
    {:ok, Redix.start_link()}
  end

  def set(key, value) do
    Redix.command!(:redix, ["SET", key, value])
  end

  def get(key) do
    Redix.command!(:redix, ["GET", key])
  end
end

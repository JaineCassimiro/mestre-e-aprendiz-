defmodule StrongboxWeb.Router do
  use StrongboxWeb, :router

  pipeline :api do
    plug :accepts, ["json"]
  end

  scope "/api", StrongboxWeb do
    pipe_through :api

    post "/artifacts", ArtifactController, :upload
    get "/artifacts/:id", ArtifactController, :show
  end
end

defmodule StrongboxWeb.ArtifactController do
  use StrongboxWeb, :controller

  def upload(conn, _params) do
    json(conn, %{message: "Upload de artefato recebido!"})
  end

  def show(conn, %{"id" => id}) do
    json(conn, %{message: "Buscando artefato com ID: #{id}"})
  end
end

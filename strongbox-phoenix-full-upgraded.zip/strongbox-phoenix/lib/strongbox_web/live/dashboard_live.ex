defmodule StrongboxWeb.DashboardLive do
  use Phoenix.LiveView

  def mount(_params, _session, socket) do
    {:ok, assign(socket, :status, "Monitorando artefatos em tempo real!")}
  end

  def render(assigns) do
    ~L"""
    <div>
      <h1>Dashboard Strongbox 🔥</h1>
      <p>Status: <%= @status %></p>
    </div>
    """
  end
end
